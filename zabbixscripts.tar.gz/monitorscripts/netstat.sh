#!/bin/bash
# Author: zhangjun3(zhangjun3@kingsoft.com)

export PATH=/usr/sbin:/sbin:$PATH

c=$(netstat -s | grep "$1" | awk '{print $1}')
if [ -z "$c" ]
then
   echo 0
else
   echo $c
fi
