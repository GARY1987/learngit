#!/bin/bash
# Author: zhangjun3(zhangjun3@kingsoft.com)

export PATH=/opt/MegaRAID/MegaCli:/usr/sbin:/sbin:$PATH

HAS_RAID="NO"
RAID_TYPE="None"

raid_info=$(lspci | grep -i RAID)
if echo "$raid_info" | grep -q "LSI"; then
    HAS_RAID="YES"; RAID_TYPE="LSI"
elif echo "$raid_info" | grep -q "Hewlett-Packard"; then
    HAS_RAID="YES"; RAID_TYPE="HP"
elif [ -n "$raid_info" ]; then
    HAS_RAID="YES"; RAID_TYPE="Unknown"
fi


discovery() {
    echo "{"
    echo "    \"data\": ["
    echo "        {\"{#RAID}\": \"$HAS_RAID\", \"{#TYPE}\": \"$RAID_TYPE\"}"
    echo "    ]"
    echo "}"
}


check_pd_status(){
    cnt=0
    if [ "$RAID_TYPE" = "LSI" ]; then
        cnt=$(MegaCli64  -cfgdsply -aALL | grep 'Firmware state' | grep -v -w Online | grep -v grep | wc -l)
    elif [ "$RAID_TYPE" = "HP" ]; then
        cnt=$(hpssacli ctrl slot=0 pd all show status | grep physicaldrive | grep -v -w OK | grep -v grep | wc -l) 
    fi
    if (( cnt >= 1 )); then
        echo "BAD"
    else
        echo "OK"
    fi
}


check_ld_status(){
    cnt=0
    if [ "$RAID_TYPE" = "LSI" ]; then
        cnt=$(MegaCli64  -LDInfo -Lall -aALL | grep State | grep -v -w Optimal | grep -v grep | wc -l)
    elif [ "$RAID_TYPE" = "HP" ]; then
        cnt=$(hpssacli ctrl slot=0 ld all show status | grep logicaldrive | grep -v -w OK | grep -v grep | wc -l)
    fi
    if (( cnt >= 1 )); then
        echo "BAD"
    else
        echo "OK"
    fi
}


check_ctrl_status(){
    false
    if [ "$RAID_TYPE" = "LSI" ]; then
        MegaCli -ShowSummary -aALL | grep -A 4 Controller | grep Status | grep -v -w Optimal &>/dev/null
    elif [ "$RAID_TYPE" = "HP" ]; then
        hpssacli ctrl all show status | grep "Controller Status" | grep -v -w OK &>/dev/null
    else
        false
    fi
    if [ $? != 0 ]; then
        echo "OK"
    else
        echo "BAD"
    fi
}


check_battery_status(){
    if [ "$RAID_TYPE" = "LSI" ]; then
        out=$(MegaCli64  -adpbbucmd -getbbustatus -aALL 2>&1)
        if echo "$out" | grep -q 'Battery Replacement required'; then
            MegaCli64 -adpbbucmd -getbbustatus -aALL 2>&1 |grep 'Battery Replacement' | grep -v -w No  &>/dev/null
        else
            false            
        fi 
    elif [ "$RAID_TYPE" = "HP" ]; then
        hpssacli ctrl all show status | grep Battery | grep -v -w OK &>/dev/null
    else
        false
    fi
    if [ $? != 0 ]; then
        echo "OK"
    else
        echo "BAD"
    fi

}


check_log() {
    state=""
    e='event'
    if [ "$RAID_TYPE" = "LSI" ]; then
        for i in critical fatal; do
	    if [ -f $e.$i ]; then
                mv $e.$i $e.$i.old
	    fi
            MegaCli64 -adpeventlog -getevents -$i -f $e.$i -aALL &> /dev/null
	    if [[ -f $e.$i && -f $e.$i.old && `cmp $e.$i $e.$i.old |wc -l` -ge 1 ]]; then
                state="$state $i" 
            fi
        done
    fi
    if [ "$state" != "" ]; then
        echo "found error in raid log, level: [$state]"
    else
        echo "OK"
    fi
}


check_media_error() {
    cnt=0
    if [ "$RAID_TYPE" = "LSI" ]; then
        cnt=$(MegaCli64  -cfgdsply -aALL | grep -E  "Error|Predictive Failure Count" | awk 'BEGIN{num=0}; {num+=$NF}; END{print num}')
    fi
    echo $cnt
}

eval $1
