#!/usr/bin/python
# Author: zhangjun3(zhangjun3@kingsoft.com)
import os
import re
import sys
import subprocess
try:
    import json
except:
    import simplejson as json

def discovery(ignore_pattern):
    output = {"data": []}

    mounts = subprocess.Popen(
        "mount|grep -E ' ext| xfs'|grep -v -i selinux", shell=True, 
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT).communicate()[0].splitlines()
    for mount in mounts:
        fields = mount.split()
        dev_path, mount_point = fields[0], fields[2]
        if ignore_pattern != "" and re.search(ignore_pattern, mount_point):
            continue
        output["data"].append({"{#FSNAME}": mount_point})

    print json.dumps(output)


if __name__ == "__main__":
    if len(sys.argv) > 1:
        ignore_pattern = sys.argv[1]
    else:
        ignore_pattern = ""
    discovery(ignore_pattern)
