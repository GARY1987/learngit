#!/bin/bash

MAX_FILE="/proc/sys/net/netfilter/nf_conntrack_max"
COUNT_FILE="/proc/sys/net/netfilter/nf_conntrack_count"
BUCKETS_FILE="/sys/module/nf_conntrack/parameters/hashsize"

MAX_LOWERBOUND=655360
MAX_UPPERBOUND=`expr $MAX_LOWERBOUND \\* 8`

function set_conntrack {
	buckets_value=`expr $1 / 8`
	echo $1 > $MAX_FILE
	echo $buckets_value > $BUCKETS_FILE
}

#if [ $# -lt 1 ]; then
#	exit 1
#fi
INTERVAL_LOWERBOUND=5000

# check if nf_conntrack module is loaded
if [ ! -f $MAX_FILE ] || 
	[ ! -f $COUNT_FILE ] || 
	[ ! -f $BUCKETS_FILE ]; then
	exit 1	
fi

# check nf_conntrack_max
max_value=`cat $MAX_FILE 2>/dev/null`
if [ "x$max_value" == "x" ]; then 
	exit 1
fi

# set nf_conntrack_max if lower then MAX_LOWERBOUND
if [ $max_value -lt $MAX_LOWERBOUND ]; then 
	max_value=$MAX_LOWERBOUND
	set_conntrack $max_value
fi

# check nf_conntrack_count
count_value=`cat $COUNT_FILE 2>/dev/null`
if [ "x$count_value" == "x" ]; then 
	exit 1
fi

# double nf_conntrack_max if nf_conntrack_count is close to nf_conntrack_max
interval_value=`expr $max_value - $count_value`
if [ $interval_value -le $INTERVAL_LOWERBOUND ]; then
	if [ $max_value -lt $MAX_UPPERBOUND ]; then
		max_value=`expr $max_value \\* 2`
		set_conntrack $max_value
	fi
fi

echo $interval_value
