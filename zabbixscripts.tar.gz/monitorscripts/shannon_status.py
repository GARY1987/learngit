#!/usr/bin/python2
# encoding: utf-8
# Author: zhangjun <zhangjun3@kingsoft.com>
import re
import sys
import os
import subprocess

def shannon(dev, info):
    p = subprocess.Popen("shannon-status -p %s" % dev, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    output = p.communicate()[0].splitlines()
    value = 0
    for o in output:
        if o.startswith("%s="%info.strip()):
            value = re.search(r".*=(\w+\.?\w+).*", o).group(1)
            break
    print value


if __name__ == "__main__":
    shannon(sys.argv[1], sys.argv[2])
        
    
