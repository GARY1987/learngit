#!/bin/bash
#Author: liuyadong@kingsoft.com

export PATH=/usr/sbin:/sbin:$PATH

df -h | grep "$1" | wc -l
