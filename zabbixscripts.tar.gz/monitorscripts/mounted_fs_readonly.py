#!/usr/bin/python
# Author: zhangjun3(zhangjun3@kingsoft.com)
import os
import sys

f = open('/proc/mounts')
for line  in f:
    L = line.split(' ')
    if os.path.isdir(L[1]) and L[2] in ['ext3','ext4','xfs'] and L[1] != '/boot':
        if L[1] == '/':
            filename = L[1] + 'fs_readonly_test.txt'
        else:
            filename = L[1] + '/fs_readonly_test.txt'
        try:
            f = open(filename,'w')
            f.write('check file system read only\n')
            f.close()
            os.remove(filename)
        except IOError:
            print "Write to %s failed" % filename
            sys.exit()
print "ok"
