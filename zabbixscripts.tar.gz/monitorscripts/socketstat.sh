#!/bin/bash
# Author: zhangjun3(zhangjun3@kingsoft.com)

export PATH=/usr/sbin:/sbin:$PATH

hostname=`cat /home/ksyun/zabbix_agent/etc/zabbix_agentd.conf  | grep '^\s*Hostname=' | awk -F= '{print $2}'`

server_port=`cat /home/ksyun/zabbix_agent/etc/zabbix_agentd.conf  | grep '^\s*ServerActive=' | awk -F= '{print $2}'`
if echo $server_port | grep -q ':'; then
    server=$(echo $server_port|cut -d ":" -f 1)
    port=$(echo $server_port|cut -d ":" -f 2)
else
    server=$server_port
    port=10052
fi

stats=`ss -s |  grep -P -o '\w+ \d+'`
rm -rf /home/ksyun/zabbix_agent/var/zabbix.basic.socketstat.txt
echo "$stats" | while read key value
do
    echo "$hostname ksc.basic.socketstat.$key $value" >> /home/ksyun/zabbix_agent/var/zabbix.basic.socketstat.txt
done
sed -i -e '/^$/d' /home/ksyun/zabbix_agent/var/zabbix.basic.socketstat.txt

/home/ksyun/zabbix_agent/bin/zabbix_sender -z $server -p $port -i /home/ksyun/zabbix_agent/var/zabbix.basic.socketstat.txt
