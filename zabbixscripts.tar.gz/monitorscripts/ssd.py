#!/usr/bin/python
import os, sys
import optparse

VENDER_LSI      = 'PCI-Express Flash SSD'
VENDER_MEMBLAZE = 'Mass storage'

LSI         = 'lsi'
MEMBLAZE    = 'memblaze'

#########################
# monitor for LSI SSD
LSI_CURRENT_TEMPERATURE = 'Current Temperature'
LSI_HEALTH              = 'Overall Health'
LSI_LIFE_LEFT           = 'SSD Life Left'
LSI_ERROR_CODE          = 'Reason Code'
LSI_BAD_BLOCKS          = 'Retired Block Count'
LSI_RAISE_ERRORS        = 'Uncorrectable RAISE Errors'
LSI_ERASE_COUNTS        = None
LSI_WRITE_AMP           = None


"""
@no<int>: the serial number of flash ssd
@filter<string>: the filter string for monitor
"""
def lsi_monitor_temperature_single(no, filter):
    command = 'ddcli -c %d -health | grep \'%s\' | awk \'{print $3}\'' %(no, filter)
    result = os.popen(command)
    res = result.read().split('\n')

    if debug:
        print res

    max_temperature = 0
    for temp in res:
        if temp != '' and int(temp) > max_temperature:
            max_temperature = int(temp)

    return max_temperature


"""
@count<int>: the number of flash ssds
@filter<string>: the filter string for monitor
"""
def lsi_monitor_temperature(count, filter):
    temperature = 0
    for i in range(count):
        tmp = lsi_monitor_temperature_single(i + 1, filter)
        if temperature < tmp:
            temperature = tmp

    print temperature


"""
@no<int>: the serial number of flash ssd
@filter<string>: the filter string for monitor
"""
def lsi_monitor_health_sigle(no, filter):
    command = 'ddcli -c %d -health | grep \'%s\' | awk \'{print $4}\'' %(no, filter)
    result = os.popen(command)
    res = result.read().split('\n')

    if debug:
        print res

    if 'GOOD' == res[0]:
        return 0
    else:
        command = 'ddcli -c %d -health | grep \'%s\' | awk \'{print $4}\'' %(no, LSI_ERROR_CODE)
        result2 = os.popen(command)
        res2 = result2.read().split('\n')
        return res2[0]
    

"""
@count<int>: the number of flash ssds
@filter<string>: the filter string for monitor
"""
def lsi_monitor_health(count, filter):
    code = 0
    for i in range(count):
        code = lsi_monitor_health_sigle(i + 1, filter)
        if 0 != code:
            break

    print code



"""
@no<int>: the serial number of flash ssd
@filter<string>: the filter string for monitor
"""
def lsi_monitor_life_single(no, filter):
    command = 'ddcli -c %d -health | grep \'%s\' | awk \'{print $6}\'' %(no, filter)
    result = os.popen(command)
    res = result.read().split('\n')
    
    if debug:
        print res

    min_life = 100 
    for life in res:
        if life != '' and int(life) < min_life:
            min_life = int(life)

    return min_life


"""
@count<int>: the number of flash ssds
@filter<string>: the filter string for monitor
"""
def lsi_monitor_life(count, filter):
    life = 100
    for i in range(count):
        tmp = lsi_monitor_life_single(i + 1, filter)
        if life > tmp:
            life = tmp

    print life


"""
@no<int>: the serial number of flash ssd
@filter<string>: the filter string for monitor
"""
def lsi_monitor_badblock_single(no, filter):
    command = 'ddcli -c %d -health | grep \'%s\' | awk \'{print $4}\'' %(no, filter)
    result = os.popen(command)
    res = result.read().split('\n')
    
    if debug:
        print res

    badblocks = 0
    for badblock in res:
        if badblock != '' and badblocks < int(badblock):
            badblocks = int(badblock)
    
    return badblocks



"""
@count<int>: the number of flash ssds
@filter<string>: the filter string for monitor
"""
def lsi_monitor_badblock(count, filter):
    badblocks = 0
    for i in range(count):
        tmp = lsi_monitor_badblock_single(i + 1, filter)
        if badblocks > tmp:
            badblocks = tmp

    print badblocks


"""
@count<int>: the number of flash ssds
@filter<string>: the filter string for monitor
"""
def lsi_monitor_erasecount(count, filter):
    pass

"""
@count<int>: the number of flash ssds
@filter<string>: the filter string for monitor
"""
def lsi_monitor_writeamp(count, filter):
    pass

"""
@type<string>: the type of event for monitor
@count<int>: the number of flash ssds
"""
def lsi_monitor(type, count):
    {
        'temperature'   : lambda: lsi_monitor_temperature(count, LSI_CURRENT_TEMPERATURE),
        'health'        : lambda: lsi_monitor_health(count, LSI_HEALTH),
        'life'          : lambda: lsi_monitor_life(count, LSI_LIFE_LEFT),
        'badblock'      : lambda: lsi_monitor_badblock(count, LSI_BAD_BLOCKS),
        'erasecount'    : lambda: lsi_monitor_erasecount(count, LSI_ERASE_COUNTS),
        'writeamp'      : lambda: lsi_monitor_writeamp(count, LSI_WRITE_AMP),
    }[type]()

# end for LSI SSD
########################


# monitor for Memblaze SSD
#######################

MEMBLAZE_CURRENT_TEMPERATURE    = 'CoreTemperature'
MEMBLAZE_HEALTH                 = 'AlertCode'
MEMBLAZE_LIFE_LEFT              = 'Device Remain Life'
MEMBLAZE_BAD_BLOCKS             = None
MEMBLAZE_ERASE_COUNTS           = None
MEMBLAZE_WRITE_AMP              = 'WriteAmplification'



"""
@count<int>: the number of flash ssds
@filter<string>: the filter string for monitor
"""
def memblaze_monitor_temperature(count, filter):
    command = 'memmonitor -l | grep \'%s\'' %(filter)
    result = os.popen(command)
    res = result.read().split('\n')

    if len(res) - 1 != count:
        print 'the num of memblaze ssd error'

    if debug:
        print res

    max_temperature = 0
    for t in res:
        if t != '':
            temperature = t.split('=')
            temperature = temperature[-1].split('C')
            temperature = float(temperature[0])

            if max_temperature < temperature:
                max_temperature = temperature

    print max_temperature

"""
@count<int>: the number of flash ssds
@filter<string>: the filter string for monitor
"""
def memblaze_monitor_health(count, filter):
    command = 'memmonitor -l | grep \'%s\'' %(filter)
    result = os.popen(command)
    res = result.read().split('\n')

    if debug:
        print res

    if len(res) - 1 != count:
        print 'the num of memblaze ssd error'

    code = 0
    for c in res:
        if c != '':
            tmp = c.split('=')
            tmp = int(tmp[-1])
            if tmp != 0:
                code = tmp
                break

    print code
                

"""
@count<int>: the number of flash ssds
@filter<string>: the filter string for monitor
"""
def memblaze_monitor_life(count, filter):
    pass


"""
@count<int>: the number of flash ssds
@filter<string>: the filter string for monitor
"""
def memblaze_monitor_badblock(count, filter):
    pass


"""
@count<int>: the number of flash ssds
@filter<string>: the filter string for monitor
"""
def memblaze_monitor_erasecount(count, filter):
    pass


"""
@count<int>: the number of flash ssds
@filter<string>: the filter string for monitor
"""
def memblaze_monitor_writeamp(count, filter):
    command = 'memmonitor -l | grep \'%s\'' %(filter)
    result = os.popen(command)
    res = result.read().split('\n')

    if debug:
        print res

    if len(res) - 1 != count:
        print 'the num of memblaze ssd error'

    amp = 0
    for a in res:
        if a != '':
            tmp = a.split('=')
            tmp = float(tmp[-1])
            if amp < tmp:
                amp = tmp

    print amp 


"""
@type<string>: the type of event for monitor
@count<int>: the number of flash ssds
"""
def memblaoze_monitor(type, count):
    {
        'temperature'   : lambda: memblaze_monitor_temperature(count, MEMBLAZE_CURRENT_TEMPERATURE),
        'health'        : lambda: memblaze_monitor_health(count, MEMBLAZE_HEALTH),
        'life'          : lambda: memblaze_monitor_life(count, MEMBLAZE_LIFE_LEFT),
        'badblock'      : lambda: memblaze_monitor_badblock(count, MEMBLAZE_BAD_BLOCKS),
        'erasecount'    : lambda: memblaze_monitor_erasecount(count, MEMBLAZE_ERASE_COUNTS),
        'writeamp'      : lambda: memblaze_monitor_writeamp(count, MEMBLAZE_WRITE_AMP),
    }[type]()


# end for Memblaze SSD
######################

def get_vendor():
    command_lsi = 'lspci -v | grep -i \'%s\'' %(VENDER_LSI)
    command_memblaze = 'lspci -v | grep -i \'%s\'' %(VENDER_MEMBLAZE)

    # check for lsi
    result_lsi = os.popen(command_lsi)
    res = result_lsi.read().split('\n')

    ssd_num = len(res) - 1
    if ssd_num > 0:
        return (LSI, ssd_num)

    # check for memblaze
    result_memblaze = os.popen(command_memblaze)
    res = result_memblaze.read().split('\n')

    ssd_num = len(res) - 1
    if ssd_num > 0:
        return (MEMBLAZE, ssd_num)

    return (None, 0)

"""
@vendor<string>: the vendor of PCIe SSD
@type<string>: the type of event for monitor
@no<int>: the serial number of flash ssd
"""
def ssd_monitor(vendor, type, no):
    {
        'lsi':      lambda: lsi_monitor(type, no),
        'memblaze': lambda: memblaoze_monitor(type, no),

    }[vendor]()

def main():
    parser = optparse.OptionParser()
    parser.add_option('-t', '--type', dest = 'type', default = None, help = 'monitor type[temperature, health, life, badblock, erasecount, writeamp]')
    parser.add_option('-d', '--debug', action="store_true", help = 'debug?')

    global debug

    (o, a) = parser.parse_args()


    if None == o.type:
        print "No type for monitor"
        return -1

    if 'temperature' != o.type and 'health' != o.type and 'life' != o.type and 'badblock' != o.type and 'erasecount' != o.type and 'writeamp' != o.type:
        print "You need specify monitor type ['temperature', 'health', 'life', 'badblock', 'erasecount', 'writeamp']"
        return -1


    if o.debug:
        debug = True
    else:
        debug = False

    (vendor, count) = get_vendor()
    if debug:
        print 'vendor: %s count: %s' %(vendor, count)

    if None == vendor:
        print 'No SSD'
        return -1

    ssd_monitor(vendor, o.type, count)

if __name__ == '__main__':
    main()

