#!/usr/bin/env python
import sys
import time
import socket
import commands
import threading
import subprocess
import os
class Server(object):
    def __init__(self):
        self.services = []
        self.hostname = self._get_hostname()
        self.ip = self._get_ip()
        self.role = self._role(self.hostname)

    def _get_ip(self):
        return socket.gethostbyname(self.hostname)

    def _get_hostname(self):
        return socket.gethostname()

    def _role(self, hostname):
        role = None
        if 'control' in hostname:
            service_name = ['nova-api', 'nova-scheduler', 'nova-network',
                            'nova-consoleauth', 'keystone-all',
                            'glance-api', 'glance-registry',
                            'cinder-api', 'cinder-scheduler', 'cinder-volume']
            role = 'controller'
        elif 'compute' in hostname:
            service_name = ['nova-compute', 'nova-network', 'libvirtd']
            role = 'compute'
        else:
            print_error()
            exit(1)

        #map(lambda x:self.services.append(Service(x)), service_name)
        return role

class Command(object):
    def __init__(self, cmd):
        self.cmd = cmd
        self.process = None
        self.FNULL = open(os.devnull, 'w')

    def run(self, timeout):
        def target():
            self.process = subprocess.Popen(self.cmd, stdout=self.FNULL, stderr=subprocess.STDOUT, shell=True)
            self.process.communicate()

        thread = threading.Thread(target=target)
        thread.start()

        thread.join(timeout)
        if thread.is_alive():
            self.process.terminate()
            thread.join()
            return 1
        else:
            return 0

class Service(object):
    def __init__(self, name=None):
        self.name = name
        self.pid = None
        self.status = self.service_status()

    def service_status(self):
        if self.name == 'libvirt':
            command =Command("virsh list")
            return command.run(timeout = 3)

        output = commands.getoutput('ps -A')
        if self.name in output:
            return 0
        return 1

# output
def print_status(status=1):
    if status == 1:
        print "libvirt_timeout"
    elif status == 0:
        print "ok"


def main(args):
    try:
        service_name = args[1]
    except IndexError:
        service_name = 'libvirt'

    service = Service(service_name)
    if service.status == 1:
        print_status(1)
    else:
        print_status(0)

if __name__=='__main__':
    main(sys.argv)

