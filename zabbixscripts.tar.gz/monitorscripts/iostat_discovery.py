#!/usr/bin/python
#encoding: utf-8
# Author: zhangjun3(zhangjun3@kingsoft.com)

import os
import re
import sys
import subprocess
try:
    import json
except:
    import simplejson as json


def discovery(ignore_mountpoints):
    p = subprocess.Popen(
        "mount|grep -E ' ext| xfs| btrfs'|grep -v -i selinux", shell=True,
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    mounts = p.communicate()[0]

    mounts = mounts.splitlines()
    disks = {}
    data = [] #忽略的磁盘名称列表
    for mount in mounts:
        fields = mount.split()
        disk =re.findall("/dev.*/(.*)", fields[0])[0]
        if disk.startswith("sd") or disk.startswith("vd") or disk.startswith("df"):
            disk = disk.strip("0123456789")
        if disk not in disks:
            disks[disk] = []
        disks[disk].append(fields[2])
    for disk in disks:
        if not ignore_mountpoints:
	        continue
        for p in disks[disk]:
            if re.search(ignore_mountpoints, p) and disk not in data:
                data.append(disk)

    p = subprocess.Popen(
        "sar -p -d  1 1 | grep Average | grep -i -E ' sd| vd|df[a-z]|bcache|root|swap|home|data|var|usr|log|www'",
        shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    sars = p.communicate()[0].splitlines()

    output = {"data": []}
    for sar in sars:
        sar = sar.split()
        if sar[1] not in data:
            output["data"].append({"{#DISKNAME}": sar[1]})
    print json.dumps(output)


if __name__ == "__main__":
    if len(sys.argv) > 1:
        ignore_mountpoints = sys.argv[1]
    else:
        ignore_mountpoints = ""

    discovery(ignore_mountpoints)
