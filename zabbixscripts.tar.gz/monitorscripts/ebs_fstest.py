#!/usr/bin/python
import eventlet
eventlet.monkey_patch()
import subprocess
from eventlet.timeout import Timeout
import datetime
import socket
import shlex
import sys
data = None

hostname = socket.gethostname()
path = "/datapool/fstest/%s" % hostname
now_time =str(datetime.datetime.utcnow())

with Timeout(5, False):
        #eventlet.sleep(5)
        f = open(path, 'w')
        f.write(now_time)
        f.close()

        f = open(path, 'r')
        t = f.readline()
        f.close()
        if t == str(now_time):
                data =  t

if data is None:
        print 'timeout'
else:
        print 'ok'

