#!/bin/bash
# Author: zhangjun3(zhangjun3@kingsoft.com)

export PATH=/usr/sbin:/sbin:$PATH

if lsmod |grep -q ttm; then
    echo 0
else
    echo 1
fi
