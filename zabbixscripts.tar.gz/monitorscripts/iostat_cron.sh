#!/bin/bash
# Author: zhangjun3(zhangjun3@kingsoft.com)

export PATH=/usr/sbin:/sbin:$PATH

r=$(sar -p -d  1  3)
echo "$r" > /home/ksyun/zabbix_agent/var/zabbix.basic.iostat
