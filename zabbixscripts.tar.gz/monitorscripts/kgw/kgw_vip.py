#!/usr/bin/python
# Author: zhangjun3(zhangjun3@kingsoft.com)

import os
import re
import sys
import subprocess
try:
    import json
except:
    import simplejson as json


AGENT='/home/work/bgwagent/bgwagent'
HOST='127.0.0.1'


def discovery():
    output = {"data": []}
    p = subprocess.Popen(
        "%s -b %s --list-service |grep VS |grep -v grep" % (AGENT, HOST), shell=True,
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    try:
        vss = p.communicate()[0].splitlines()
        for vs in vss:
            vip, port, proto, name = re.match(r"VS (.*):([0-9]+)\((.*),(.*)\)", vs).groups()
            output["data"].append({"{#VIP}": vip, "{#PORT}": port, "{#PROTO}": proto, "{#NAME}": name})
    except Exception:
         pass
    print json.dumps(output)


def get_value(vip_port, _type):
    p = subprocess.Popen(
        "%s -b %s --list-service -t %s --show-stats |grep -w %s |grep -v grep" % (AGENT, HOST, vip_port, _type), shell=True,
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    try: 
        value = p.communicate()[0].split(":")[1].split(",")
        print int("".join(value))
    except Exception:
        print 0


if __name__  == "__main__":
    if sys.argv[1] == "discovery":
        discovery()
    elif sys.argv[1] == "value":
        get_value(sys.argv[2], sys.argv[3])
