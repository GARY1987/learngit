#!/usr/bin/python
# Author: zhangjun3(zhangjun3@kingsoft.com)

import os
import re
import sys
import subprocess
try:
    import json
except:
    import simplejson as json


AGENT='/home/work/bgwagent/bgwagent'
HOST='127.0.0.1'


def discovery():
    output = {"data": []}
    result = subprocess.Popen(
            "%s -b %s --list-ratio |grep -E '^\s*receiver|worker' || echo failed" % (AGENT, HOST), shell=True,
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT).communicate()[0]
    if "failed" not in result:
        for cpu in result.splitlines():
            fields = cpu.split()
            output["data"].append({"{#CPU}": "%s_%s" % (fields[0], fields[1])})
    print json.dumps(output)


def get_value(cpu):
    process, num = cpu.split("_")
    result = subprocess.Popen(
            "%s -b %s --list-ratio |grep -E '%s\s*%s' |sed -e 's/%%//g'" % (AGENT, HOST, process, num), shell=True,
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT).communicate()[0].splitlines()[0].split()[3]
    print result


if __name__  == "__main__":
    if sys.argv[1] == "discovery":
        discovery()
    elif sys.argv[1] == "value":
        get_value(sys.argv[2])
