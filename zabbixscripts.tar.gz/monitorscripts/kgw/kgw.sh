#!/bin/sh
# Author: zhangjun3(zhangjun3@kingsoft.com)

export PATH=/usr/sbin:/sbin:$PATH

AGENT='/home/work/bgwagent/bgwagent'
HOST='127.0.0.1'


function vnic_flow() {

    STATS_OUTPUT=$($AGENT -b $HOST --list-port-stats 2>&1)
    pre=$(echo "$STATS_OUTPUT" |grep -A8 "vnic0 statics" |grep "$1" |awk -F: '{print $NF}' |sed "s/ //g")

    sleep 1

    STATS_OUTPUT=$($AGENT -b $HOST --list-port-stats 2>&1)
    after=$(echo "$STATS_OUTPUT" |grep -A8 "vnic0 statics" -A8 |grep "$1" |awk -F: '{print $NF}' |sed "s/ //g")

    [ -z $pre ] && pre=0
    [ -z $after ] && after=0

    if [[ $1 =~ _bytes ]]; then
        echo $(((after - pre) * 8)) 
    else
        echo $((after - pre)) 
    fi

}


function bgw_stats() {

	BGW_OUTPUT=$($AGENT -b $HOST --list-bgwinfo 2>&1)
	KPD_OUTPUT=$($AGENT -b $HOST -k 2>&1)
    
    if [[ $1 =~ curr_conn ]]; then
      result=$(echo "$BGW_OUTPUT" |grep "$1" |awk -F: '{print $NF}' |sed 's/ //g')
    else	
      result=$(echo "$KPD_OUTPUT" |grep "$1" |awk -F: '{print $NF}' |sed 's/ //g')
    fi

    if [ -z "$result" ]; then
        echo 0
    else
        echo "$result"
    fi
}


function cpu_ctrl_5() {
	CTR_CPU_IDLE=$(sar -P ALL 1 1 | awk '{if($3==5) print $NF}' |head -1 | awk -F. '{print $1}')
	CTR_CPU_USAGE=$((100 - $CTR_CPU_IDLE))
	echo $CTR_CPU_USAGE
}


function ps_stats() {
    NUM=$(pidof $1 | wc -w)
    echo $NUM
}


function log() {
	CUR_MIN=$(date '+%b %e %H:%M')
	LOG_FILE="/home/work/bgw/log/bgw.log"
	echo $(grep -c "$CUR_MIN" $LOG_FILE)
}


case $1 in
    rx_bytes|tx_bytes|rx_pkts|tx_pkts)
        vnic_flow $1 ;;
    curr_conn|kpd_vip_num|kpd_vs_num|chk_num|bgw_kpd_rs|pkt_send_out_failed)
        bgw_stats $1 ;;    
    cpu_ctrl_5)
        cpu_ctrl_5;;
    bgw|ospfd|zebra)
        ps_stats $1 ;;
    log)
        log ;;
esac
