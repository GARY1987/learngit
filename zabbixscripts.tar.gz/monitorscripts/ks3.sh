#!/bin/bash
# Author: zhangjun3(zhangjun3@kingsoft.com)

export PATH=/usr/sbin:/sbin:$PATH

# ks3 download
function ks3_download() {
    log=/tmp/ks3_download.log
    error_log=/tmp/ks3_download_error.log

    uri="$1"
    if [[ $uri == "" ]]; then
        uri="http://monitor.kss.ksyun.com/cgroups.txt"
    fi

    code=$(curl --connect-timeout 5 -s -o /dev/null -w "%{http_code}" -D "$log" $uri)
    if [[ $code != 200 ]]; then

        cat $log >> $error_log
        cat $log | grep -v '100 Continue' | tr -d '\r' > ${log}2

        http_line=$(awk '($1 ~ /HTTP/) {$1=""; print $0}' "${log}2")
        id=$(awk '($1 ~ /x-kss-request-id/) {print $2}' "${log}2")
        echo "KS3下载测试失败:$uri,$http_line,request-id:$id"
    fi

    echo >$log
}

# ks3 upload
function ks3_upload() {
    log=/tmp/ks3_upload.log
    error_log=/tmp/ks3_upload_error.log

    file=/tmp/ks3_upload_$$
    echo 123 > $file

    uri="$1"
    if [[ $uri == "" ]]; then
        uri="http://monitor.kss.ksyun.com"
    fi

    code=$(curl --connect-timeout 5 -s -o /dev/null -w "%{http_code}" --form key=test --form acl=public-read --form success_action_status=204 \
        --form x-kss-meta-t1=2 --form x-kss-meta-t2=t2 --form Content-Disposition="inlne;t.txt" --form KSSAccessKeyId=4GUNIJJXXQHCN4HXHFOA  \
        --form Policy=eyJleHBpcmF0aW9uIjoiMjExNS0wMS0xNlQxMzozNzo0My42MzlaIiwiY29uZGl0aW9ucyI6W1siZXEiLCIkYnVja2V0IiwibW9uaXRvciJdLFsiZXEiLCIka2V5IiwidGVzdCJdLFsiZXEiLCIkYWNsIiwicHVibGljLXJlYWQiXSxbImVxIiwiJHN1Y2Nlc3NfYWN0aW9uX3N0YXR1cyIsIjIwNCJdLFsiZXEiLCIkeC1rc3MtbWV0YS10MSIsIjIiXSxbImVxIiwiJHgta3NzLW1ldGEtdDIiLCJ0MiJdLFsiZXEiLCIkQ29udGVudC1EaXNwb3NpdGlvbiIsImlubG5lO3QudHh0Il1dfQ== \
        --form Signature=4NCLK06x9riqX84m675yNZA3YtY= --form FILE=$file -D $log $uri)
    rm -rf $file

    if [ $code != 204 ]; then
        cat $log >> $error_log
        cat $log | grep -v '100 Continue' |tr -d '\r' > ${log}2

        http_line=$(awk '($1 ~ /HTTP/) {$1=""; print $0}' "${log}2")
        id=$(awk '($1 ~ /x-kss-request-id/) {print $2}' "${log}2")
        echo "KS3上传测试失败:$uri,$http_line,request-id:$id"
    fi

    echo > $log
}

# xiaomi appbak download
function xm_appbak_download() {
    log=/tmp/ks3_xm_download.log
    error_log=/tmp/ks3_xm_download_error.log

    uri="$1"
    if [[ $uri == "" ]]; then
        uri="http://xiaomi-appbak.sdns.ksyun.com/monitor/appbackup"
    fi

    code=$(curl --connect-timeout 5 -s -o /dev/null -w "%{http_code}" -D "$log" $uri)
    if [[ $code != 200 ]]; then

        cat $log >> $error_log
        cat $log | grep -v '100 Continue' | tr -d '\r' > ${log}2

        http_line=$(awk '($1 ~ /HTTP/) {$1=""; print $0}' "${log}2")
        id=$(awk '($1 ~ /x-kss-request-id/) {print $2}' "${log}2")
        echo "小米应用备份下载测试失败:$uri,$http_line,request-id:$id"
    fi

    echo >$log
}


# xiaomi appbak upload
function xm_appbak_upload() {
    log=/tmp/ks3_xm_upload.log
    error_log=/tmp/ks3_xm_upload_error.log

    file=/tmp/ks3_xm_upload_$$
    echo 123 > $file

    uri="$1"
    if [[ $uri == "" ]]; then
        uri="http://xiaomi-appbak.sdns.ksyun.com/monitor"
    fi

    code=$(curl --connect-timeout 5 -s -o /dev/null -w "%{http_code}" --form key=test --form acl=public-read --form success_action_status=204 \
        --form x-kss-meta-t1=2 --form x-kss-meta-t2=t2 --form Content-Disposition="inlne;t.txt" --form KSSAccessKeyId=4GUNIJJXXQHCN4HXHFOA  \
        --form Policy=eyJleHBpcmF0aW9uIjoiMjExNS0wMS0xNlQxMzozNzo0My42MzlaIiwiY29uZGl0aW9ucyI6W1siZXEiLCIkYnVja2V0IiwibW9uaXRvciJdLFsiZXEiLCIka2V5IiwidGVzdCJdLFsiZXEiLCIkYWNsIiwicHVibGljLXJlYWQiXSxbImVxIiwiJHN1Y2Nlc3NfYWN0aW9uX3N0YXR1cyIsIjIwNCJdLFsiZXEiLCIkeC1rc3MtbWV0YS10MSIsIjIiXSxbImVxIiwiJHgta3NzLW1ldGEtdDIiLCJ0MiJdLFsiZXEiLCIkQ29udGVudC1EaXNwb3NpdGlvbiIsImlubG5lO3QudHh0Il1dfQ== \
        --form Signature=4NCLK06x9riqX84m675yNZA3YtY= --form FILE=$file -D $log $uri)
    rm -rf $file

    if [ $code != 204 ]; then
        cat $log >> $error_log
        cat $log | grep -v '100 Continue' |tr -d '\r' > ${log}2

        http_line=$(awk '($1 ~ /HTTP/) {$1=""; print $0}' "${log}2")
        id=$(awk '($1 ~ /x-kss-request-id/) {print $2}' "${log}2")
        echo "小米应用备份上传测试失败:$uri,$http_line,request-id:$id"
    fi
    
    echo >$log
}

# thumbnail
function thumbnail_download() {
    log=/tmp/ks3_thumbnail_download.log
    error_log=/tmp/ks3_thumbnail_download_error.log

    uri="$1"
    if [[ $uri == "" ]]; then
        uri="http://kss.ksyun.com/terry-1/IMG_0827.JPG@base@tag=imgBaseOp&mode=0&w=50&h=50"
    fi

    code=$(curl --connect-timeout 5 -s -o /dev/null -w "%{http_code}" -D "$log" $uri)
    if [[ $code != 200 ]]; then

        cat $log >> $error_log
        cat $log | grep -v '100 Continue' | tr -d '\r' > ${log}2

        http_line=$(awk '($1 ~ /HTTP/) {$1=""; print $0}' "${log}2")
        id=$(awk '($1 ~ /x-kss-request-id/) {print $2}' "${log}2")
        echo "缩略图监控测试失败:$uri,$http_line,request-id:$id"
    fi

    echo >$log
}

# check kss api
function kss_api() {
    log=/tmp/kss_api.log
    error_log=/tmp/kss_api_error.log

    uri="$1"
    if [[ $uri == "" ]]; then
        uri="http://kss.ksyun.com/monitor/cgroups.txt"
    fi

    code=$(curl --connect-timeout 5 -s -o /dev/null -w "%{http_code}" -D "$log" $uri)
    if [[ $code != 200 ]]; then

        cat $log >> $error_log
        cat $log | grep -v '100 Continue' | tr -d '\r' > ${log}2

        http_line=$(awk '($1 ~ /HTTP/) {$1=""; print $0}' "${log}2")
        id=$(awk '($1 ~ /x-kss-request-id/) {print $2}' "${log}2")
        echo "KSS API测试失败:$uri,$http_line,request-id:$id"
    fi

    echo >$log
}

# check kss console api
function kss_console_api() {
    log=/tmp/kss_console_api.log
    error_log=/tmp/kss_console_api_error.log

    uri="$1"
    if [[ $uri == "" ]]; then
        uri="http://console.ksyun.com/kss/accessKeyList?userid=73398481"
    fi

    code=$(curl --connect-timeout 5 -s -o /dev/null -w "%{http_code}" -D "$log" $uri)
    if [[ $code != 200 ]]; then

        cat $log >> $error_log
        cat $log | grep -v '100 Continue' | tr -d '\r' > ${log}2

        http_line=$(awk '($1 ~ /HTTP/) {$1=""; print $0}' "${log}2")
        id=$(awk '($1 ~ /x-kss-request-id/) {print $2}' "${log}2")
        echo "KSS Console API测试失败:$uri,$http_line,request-id:$id"
    fi

    echo >$log
}

eval $1 $2
