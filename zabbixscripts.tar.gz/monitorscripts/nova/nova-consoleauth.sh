hosts=`cat ./nova_consoleauth.txt`
for host in $hosts
  do
    stat=`./nova-manage.py $host nova-consoleauth`
    if [ "$stat" != "ok" ];then
      res="$res $host"
    fi
  done
if  [ -n "$res" ];then
  echo "$res  nova-consoleauth fail"
  exit 2
else
  echo "nova-consoleauth ok"
  exit 0
fi

