hosts=`cat ./nova_network.txt`
for host in $hosts
do
   stat=`./nova-manage.py $host nova-compute`
   if [ "$stat" != "ok" ];then
       res="$res $host"
   fi
done
if  [ -n "$res" ];then
  echo "$res  nova-compute fail"
  exit 2
else
  echo "nova-compute ok"
  exit 0
fi

