hosts=`cat ./nova_network.txt`
for host in $hosts
do
   stat=`./nova-manage.py $host nova-network`
   if [ "$stat" != "ok" ];then
       res="$res $host"
   fi
done
if  [ -n "$res" ];then
  echo "$res  nova-network fail"
  exit 2
else
  echo "nova-network ok"
  exit 0
fi


