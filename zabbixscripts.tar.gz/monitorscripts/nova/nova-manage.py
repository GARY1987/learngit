#!/usr/bin/python
# -*- coding: utf-8 -*-
import sys
from nova import utils


#监控nova相关的服务状态
#param: hostname名称
#服务名称(接受nova-compute,nova-service,nova-consoleauth,nova-scheduler)

if len(sys.argv) >2:
        host = sys.argv[1]
        service = sys.argv[2]
else:
        sys.exit(1)

out,err = utils.trycmd("/usr/bin/sudo","/usr/bin/nova-manage","service", "list", "--host=%s"%host,"--service=%s" % service)
#print out
try:
        out.index(":-)")
        print "ok"
except:
        print host,service,"fail"

