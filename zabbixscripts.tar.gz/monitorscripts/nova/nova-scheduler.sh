hosts=`cat ./nova_consoleauth.txt`
for host in $hosts
  do
    stat=`./nova-manage.py $host nova-scheduler`
    if [ "$stat" != "ok" ];then
      res="$res $host"
    fi
  done
if  [ -n "$res" ];then
  echo "$res  nova-scheduler fail"
  exit 2
else
  echo "nova-scheduler ok"
  exit 0
fi

