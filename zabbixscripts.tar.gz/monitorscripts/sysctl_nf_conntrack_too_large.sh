#!/bin/bash

MAX_FILE="/proc/sys/net/netfilter/nf_conntrack_count"

# check if nf_conntrack module is loaded
if [ ! -f $MAX_FILE ]; then
	exit 1	
fi

# check nf_conntrack_max
max_value=`cat $MAX_FILE 2>/dev/null`
if [ "x$max_value" == "x" ]; then 
	exit 1
fi

echo $max_value
