#!/bin/bash
# Author: zhangjun3(zhangjun3@kingsoft.com)

export PATH=/usr/sbin:/sbin:$PATH

ifstat () {
    state=$(cat /sys/class/net/$1/operstate)
    if [[ $state == "unknown" ]]; then
       if ip link show |grep -E " $1@?" |grep -q ",UP,"; then
           state="up"
       fi
    fi
    echo $state
}

discovery() {
    if_file="/tmp/if_stat$$" 
    touch $if_file
    ip link show|awk -F: '($1 ~ /^[0-9]+/){print $2}' | while read interface; do
        interface=${interface%%@*}
        # $1 为忽略的网卡名称正则表达式列表 
        if [ -n "$1" ]; then
            echo "$interface" |grep -q -E "$1" || echo "$interface" >> $if_file
        else
            echo "$interface" >> $if_file
        fi 
    done 

    echo '{'
    echo '"data":['
    n=0
    num=$(cat $if_file | wc -l)
    for interface in $(cat $if_file); do
        ((n+=1))
        stat=$(ifstat $interface)
        if cat /sys/class/net/$interface/speed &>/dev/null; then
            speed=$(cat /sys/class/net/$interface/speed)
        else
            speed=65535
        fi
        echo "{"
        echo "\"{#IFNAME}\":\"${interface}\",\"{#IFSTAT}\":\"$stat\",\"{#IFSPEED}\":$speed"
        if [[ $n != $num ]]; then
            echo "},"
        else
            echo "}"
        fi
    done 
    echo "]"
    echo '}'

    rm $if_file
}


if [ "$1" = "discovery" ]; then
    discovery "$2"
elif [ "$1" = "ifstat" ]; then
    ifstat "$2"
fi
