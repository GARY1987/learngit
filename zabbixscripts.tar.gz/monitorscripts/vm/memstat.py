#!/usr/bin/python
# Author: zhangjun3(zhangjun3@kingsoft.com)

import os
import re
import sys
import subprocess
try:
    import json
except:
    import simplejson as json


def doExec(cmd):
    return subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT).communicate()[0]


def discovery():
    output = {"data": []}
    uuids = doExec("virsh list --all --uuid").splitlines()
    for uuid in uuids:
        uuid = uuid.strip()
        if uuid == "":
            continue
        stat = {"{#UUID}": uuid}
        output["data"].append(stat)
    print json.dumps(output)


def get_value(uuid, type_):
    memstat = doExec("virsh dommemstat %s" % uuid)
    m = re.findall(r"%s (\S+)" % type_, memstat, re.M|re.DOTALL)
    if m == []:
        print 0
    else:
        print  m[0]


if __name__ == "__main__":
    if sys.argv[1] == "discovery":
        discovery()
    else:
        get_value(sys.argv[1], sys.argv[2])
