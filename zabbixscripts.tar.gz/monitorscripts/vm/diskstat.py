#!/usr/bin/python
# Author: zhangjun3(zhangjun3@kingsoft.com)

import os
import re
import sys
import subprocess
try:
    import json
except:
    import simplejson as json


def doExec(cmd):
    return subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT).communicate()[0]


def discovery(ignoreDisks="disk.local"):
    output = {"data": []}
    uuids = doExec("virsh list --all --uuid").splitlines()
    for uuid in uuids:
        uuid = uuid.strip()
        if uuid == "":
            continue
        blklist = doExec("virsh domblklist %s" % uuid).splitlines()[2:]
        for line in blklist:
            line = line.strip()
            if line == "":
                continue
            line = line.split(" ")
            target, source = line[0], line[-1]
            source = os.path.basename(source)
            if ignoreDisks != "" and re.search(ignoreDisks, source):
                continue
            stat = {"{#UUID}": uuid, "{#DISK}": target, "{#NAME}": source}
            output["data"].append(stat)
    print json.dumps(output)


def get_value(uuid, disk, type_):
    blkstat = doExec("virsh domblkstat %s %s" % (uuid, disk))
    m = re.findall(r"%s (\S+)" % type_, blkstat, re.M|re.DOTALL)
    if m == []:
        print 0
    else:
        print  m[0]


if __name__ == "__main__":
    if sys.argv[1] == "discovery":
        discovery(sys.argv[2])
    else:
        get_value(sys.argv[1], sys.argv[2], sys.argv[3])
