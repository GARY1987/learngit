#!/usr/bin/python
# Author: zhangjun3(zhangjun3@kingsoft.com)

import os
import re
import sys
import subprocess
try:
    import json
except:
    import simplejson as json


def doExec(cmd):
        return subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT).communicate()[0]


def discovery():
    output = {"data": []}

    uuids = doExec("virsh list --all --uuid").splitlines()
    for uuid in uuids:
        uuid = uuid.strip()
        if uuid == "":
            continue
        iflist = doExec("virsh domiflist %s" % uuid).splitlines()[2:]
        for line in iflist:
            line = line.strip()
            if line == "":
                continue
            nic = line.split(" ")[0]
            stat = {"{#UUID}": uuid, "{#NIC}": nic}
            output["data"].append(stat)
    print json.dumps(output)


def get_value(uuid, nic, direction):
    ifstat = doExec("virsh domifstat %s %s" % (uuid, nic))
    m = re.findall(r"rx_bytes (\S+).*tx_bytes (\S+)", ifstat, re.M|re.DOTALL)
    if m == []:
        print 0
    elif direction == "RX":
        print m[0][0]
    else:
        print m[0][1]


if __name__ == "__main__":
    if sys.argv[1] == "discovery": 
        discovery()
    else:
        get_value(sys.argv[1], sys.argv[2], sys.argv[3])
