#!/usr/bin/python
# Author: zhangjun3(zhangjun3@kingsoft.com)
import sys
import urllib2
import subprocess
try:
    import json
except:
    import simplejson as json

greinfo_url = "http://monitor.sdns.ksyun.com/api/greinfo?ip=%s"

ret = {"data": []}
s = urllib2.urlopen(greinfo_url % sys.argv[1])
gres = json.loads(s.read())["info"]
for gre in gres:
    ret["data"].append({
        "{#DEST}": gre["Dest"],
        "{#NUM}": gre["Number"],
        "{#WARN}": gre["Warn"],
        "{#CRITICAL}": gre["Critical"],
        "{#NOTE}": gre["Note"]}
    )
print json.dumps(ret, ensure_ascii=False).encode("utf-8")
