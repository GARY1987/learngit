#!/bin/bash
# Author: zhangjun3(zhangjun3@kingsoft.com)

export PATH=/usr/sbin:/sbin:$PATH

ssds=''
echo '{'
echo '"data":['
for path in /sys/block/sd*;do
    rotational=$(cat ${path}/queue/rotational);
    if [[ $rotational = 0 ]]; then
        disk=${path##*/}
        ssds=$ssds" "$disk
    fi
done
num=$(echo $ssds|wc -w)
n=1
for ssd in $ssds; do
    if [[ $n < $num ]]; then
        echo "{\"{#SSD}\":\"$ssd\"},"
    else
        echo "{\"{#SSD}\":\"$ssd\"}"
    fi
    ((n+=1))
done
echo ']'
echo '}'
