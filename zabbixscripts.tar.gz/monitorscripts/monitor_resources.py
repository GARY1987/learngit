#!/usr/bin/python
import requests,json,re
import ConfigParser

vmapi_url = "http://10.3.1.1:9998/"
nova_config = "/etc/nova/nova.conf"
log_file = open("/tmp/monitor_resources.log","a+")
enable_stdout =  False
http_log_debug = False 

CPU_LIMIT = 0.9
MEM_LIMIT = 0.9
IP_LIMIT = 0.85

import sys
origin_stdout = sys.stdout
if not enable_stdout:
    sys.stdout = log_file



def http_log_req(args, kwargs):
        if not http_log_debug:
            return

        string_parts = ['curl -i']
        for element in args:
            if element in ('GET', 'POST', 'DELETE', 'PUT'):
                string_parts.append(' -X %s' % element)
            else:
                string_parts.append(' %s' % element)

        for element in kwargs['headers']:
            header = ' -H "%s: %s"' % (element, kwargs['headers'][element])
            string_parts.append(header)

        if 'data' in kwargs:
            string_parts.append(" -d '%s'" % (kwargs['data']))
        log_file.write("\nREQ: %s\n" % "".join(string_parts))
        
        
def http_log_resp(resp):
        if not http_log_debug:
            return
        log_file.write(
            "RESP: [%s] %s\nRESP BODY: %s\n",
            resp.status_code,
            resp.headers,
            resp.text)
        
def format_hostname(hostname):
    t =re.search('([0-9]+\-[0-9]+)',hostname)
    if t:
        return ".".join(t.group(0).split("-"))
    return hostname
        


def request(url, method, **kwargs):
        url = vmapi_url + url
        kwargs.setdefault('headers', kwargs.get('headers', {}))
        kwargs['headers']['User-Agent'] = "monitor-resources"
        kwargs['headers']['Accept'] = 'application/json'
        if 'body' in kwargs:
            kwargs['headers']['Content-Type'] = 'application/json'
            kwargs['data'] = json.dumps(kwargs['body'])
            del kwargs['body']

        http_log_req((url, method,), kwargs)
        resp = requests.request(
            method,
            url,
            **kwargs)
        http_log_resp(resp)
        
        
        if resp.status_code == 200:
            if resp.text:
                try:
                    body = json.loads(resp.text)
                except ValueError:
                    pass
                    body = None
            else:
                body = None
            return body

        
        raise Exception("%s %s" % (resp.status_code, url))
    
try:
    ALARM_CPU = []
    ALARM_MEM = [] 
    ALARM_IP = []
    config = ConfigParser.ConfigParser()
    config.read(nova_config)
    cpu_ration =  int(config.get('DEFAULT','cpu_allocation_ratio'))
    mem_ration = float(config.get('DEFAULT','ram_allocation_ratio'))
    
    
    authenticate_body = {'name':'admin','password':'ksc'}
    authenticate_resp =  request("user/authenticate","POST",body=authenticate_body)

    admin_token = authenticate_resp['token']
    common_headers = {'X-Auth-Token':admin_token}
    zoneInfo_resp =  request("stat/zones","GET",headers=common_headers)
    #print json.dumps(zoneInfo_resp, sort_keys=True, indent=4, separators=(',', ': '))
    for node in zoneInfo_resp[0]['host_usage']:
        hostname = format_hostname(node['hostname'])
        vcpus = int(node['vcpus'])
        max_vcpus = vcpus*cpu_ration
        vcpus_used = int(node['vcpus_used'])
        cpu_alarm_ration = float(vcpus_used) / max_vcpus
        
        memory_mb = int(node['memory_mb'])
        memory_mb_used = int(node['memory_mb_used'])
        max_memory = memory_mb * mem_ration
        
        mem_alarm_ration = memory_mb_used / max_memory
        
        if cpu_alarm_ration >= CPU_LIMIT:
            print "CPU ALARM",hostname,vcpus,max_vcpus,vcpus_used,cpu_alarm_ration
            ALARM_CPU.append(hostname)
        if mem_alarm_ration >= MEM_LIMIT:
            print "MEM_ALARM",hostname,memory_mb,max_memory,memory_mb_used,mem_alarm_ration
            ALARM_MEM.append(hostname)
            
            
    zoneIp_resp =  request("stat/zones/ipstat","GET",headers=common_headers)
    for zone in zoneIp_resp:
        ip_num = 0
        used_ipnum = 0
        for ip in zone['lan']:
            ip_num = ip_num  + int(ip['ipnum'])
            used_ipnum = used_ipnum + int(ip['used_ipnum'])
        
        alarm_lan_ration = float(used_ipnum) / ip_num
        
        if alarm_lan_ration >= IP_LIMIT:
            print 'alarm_lan',ip_num,used_ipnum,alarm_lan_ration
            ALARM_IP.append(zone['zone_name']+" lan_ip")
        
        ip_num = 0
        used_ipnum = 0
        for ip in zone['wan']:
            ip_num = ip_num  + int(ip['ipnum'])
            used_ipnum = used_ipnum + int(ip['used_ipnum'])
            
        
        alarm_wan_ration = float(used_ipnum) / ip_num
        if alarm_wan_ration >= IP_LIMIT:
            print 'alarm_wan',ip_num,used_ipnum,alarm_wan_ration
            ALARM_IP.append(zone['zone_name']+" wan_ip")
        pass
    #print json.dumps(zoneIp_resp, sort_keys=True, indent=4, separators=(',', ': '))

except Exception as e:
    print e

sys.stdout = origin_stdout
if not ALARM_CPU  and not ALARM_MEM and not ALARM_IP:
	print 'ok'

else:
	print "cpu_alarm:",ALARM_CPU,"\n mem_alarm:",ALARM_MEM,"\n ip_alarm",ALARM_IP
