#!/bin/bash
# Author: zhangjun3(zhangjun3@kingsoft.com)

export PATH=/usr/sbin:/sbin:$PATH

function queue_length() {
    if echo $(hostname) |grep -q -E '^sh[0-9]+'; then # for shanghai IDC
        status=$(/usr/sbin/rabbitmqctl -n rds list_queues | awk '!/^Listing/{if($2 >= '"$1"') print $1,$2}')
    else
        status=$(/usr/sbin/rabbitmqctl list_queues | grep -v notifications| awk '!/^Listing/{if($2 >= '"$1"') print $1,$2}')
    fi

    if [ -z "$status" ];then
        echo "OK"
    else
        echo -n "$status" | tr '\n' ','
    fi
}


function autobackup_cnt() {
    count=0

    if echo $(hostname) |grep -q -E '^sh[0-9]+'; then # for shanghai IDC
        count=$(/usr/sbin/rabbitmqctl -n rds list_queues |grep autobackup |grep -v grep |wc -l)
    else
        count=$(/usr/sbin/rabbitmqctl list_queues | grep autobackup |grep -v grep |wc -l)
    fi

    echo $count
}

function monitor_cnt() {
    count=0

    if echo $(hostname) |grep -q -E '^sh[0-9]+'; then # for shanghai IDC
        count=$(/usr/sbin/rabbitmqctl -n rds list_queues |grep monitor |grep -v grep |wc -l)
    else
        count=$(/usr/sbin/rabbitmqctl list_queues | grep monitor |grep -v grep |wc -l)
    fi

    echo $count
}

function taskmanager() {
    count=0

    if echo $(hostname) |grep -q -E '^sh[0-9]+'; then # for shanghai IDC
        count=$(/usr/sbin/rabbitmqctl -n rds list_queues | grep taskmanager | sed -n '1p;1q' | awk '{print $2}')
    else
        count=$(/usr/sbin/rabbitmqctl list_queues | grep taskmanager | sed -n '1p;1q' | awk '{print $2}')
    fi

    echo $count

}

if [ $1 == "queue_length" ]; then
    queue_length "$2"
elif [ $1 == "autobackup_cnt" ]; then
    autobackup_cnt
elif [ $1 == "monitor_cnt" ]; then
    monitor_cnt
elif [ $1 == "taskmanager" ]; then
    taskmanager
fi
