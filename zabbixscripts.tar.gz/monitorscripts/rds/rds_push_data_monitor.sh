#!/bin/bash
#Author: liuyadong<liuyadong@kingsoft>

export PATH=/usr/sbin:/sbin:$PATH

redis_push_data=0
pid=$(ps -ef| grep 9000| grep java| awk '{print $2}')

if [ -n "$pid" ]
then
    redis_push_data=`jstack $pid| grep redisServiceGroup| wc -l`
fi
echo $redis_push_data
