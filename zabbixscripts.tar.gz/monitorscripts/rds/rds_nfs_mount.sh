#!/bin/bash
#Author: liuyadong<liuyadong@kingsoft>

export PATH=/usr/sbin:/sbin:$PATH

nfsiostat | grep mounted | grep "$1" | wc -l
