#!/bin/bash
# Author: zhangjun3(zhangjun3@kingsoft.com)
PWD=/home/ksyun/zabbix_agent/share/zabbix/monitorscripts
$PWD/check_ping -H "$1" -p "$2" -w "$3" -c "$4" | awk -F "|" '{print $1}'
